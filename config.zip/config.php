<?php
// +------------------------------------------------------------------------+
// | @author Aminul Islam
// | @author_url 1: http://www.vrbel.com
// | @author_email: admin@vrbel.com
// +------------------------------------------------------------------------+
// | Project Management
// | Copyright (c) 2022 Vrbel. All rights reserved.
// +------------------------------------------------------------------------+
// MySQL Hostname
$sql_db_host = "localhost";
// MySQL Database User
$sql_db_user = "civicbd_group";
// MySQL Database Password
$sql_db_pass = "?wjgo8;k=L~_QXPi8r";
// MySQL Database Name
$sql_db_name = "civicbd_group";

// Site URL
$site_url = $domain_details['domain']; // e.g (http://example.com)

$auto_redirect = true;

// Purchase code
$purchase_code = "4483-369-49823-5698-44256"; // Your purchase code, don't give it to anyone.

?>
